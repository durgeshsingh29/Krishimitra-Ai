---
name: Gemini role mapping
description: Gemini API uses "model" for assistant messages — never "assistant"
---

# Rule
When building Gemini chat history from DB messages, map `role === "assistant"` → `"model"`.

**Why:** The `@google/genai` SDK only accepts `"user"` and `"model"` as valid roles. Passing `"assistant"` causes an API error.

**How to apply:** Always do: `role: (m.role === "assistant" ? "model" : "user") as "user" | "model"` when constructing `contents` for `generateContent` or `generateContentStream`.
