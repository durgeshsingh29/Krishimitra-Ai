---
name: Gemini esbuild bundling
description: @google/genai must be bundled by esbuild, not externalized — otherwise the server crashes at runtime
---

# Rule
Remove `"@google/*"` from the `external` array in `artifacts/api-server/build.mjs` when using `@workspace/integrations-gemini-ai`.

**Why:** The integrations lib has `@google/genai` as its dependency. If esbuild externalizes `@google/*`, the package won't be found at runtime because it's not a direct dependency of api-server. Removing it from external makes esbuild bundle it into `dist/index.mjs`.

**How to apply:** Any time you add a new `@google/*` package to the integrations lib, check that it's not in the external list. Keep `@google-cloud/*` external only if using actual Google Cloud SDKs that load `.proto` files at runtime.
