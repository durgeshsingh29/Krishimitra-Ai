import { pgTable, serial, text, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const diseaseDetections = pgTable("disease_detections", {
  id: serial("id").primaryKey(),
  cropName: text("crop_name").notNull(),
  diseaseName: text("disease_name").notNull(),
  severity: text("severity").notNull(),
  confidence: real("confidence").notNull(),
  description: text("description").notNull().default(""),
  recommendations: text("recommendations").array().notNull().default([]),
  preventionTips: text("prevention_tips").array().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertDiseaseDetectionSchema = createInsertSchema(diseaseDetections).omit({
  id: true,
  createdAt: true,
});

export type DiseaseDetection = typeof diseaseDetections.$inferSelect;
export type InsertDiseaseDetection = z.infer<typeof insertDiseaseDetectionSchema>;
