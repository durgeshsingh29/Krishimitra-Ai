# KrishiMitra AI

An AI-powered farm intelligence platform for Indian farmers — crop advisory chat (Gemini), disease detection via image upload, weather forecasting, and live market prices.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/krishimitra run dev` — run the React frontend (Vite)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL`, `GEMINI_API_KEY`, `SESSION_SECRET`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui + wouter routing
- API: Express 5 with SSE streaming for Gemini chat
- DB: PostgreSQL + Drizzle ORM (tables: conversations, messages, disease_detections)
- AI: Gemini 2.5 Flash via `@workspace/integrations-gemini-ai` → `@google/genai`
- API codegen: Orval (OpenAPI → React Query hooks + Zod schemas)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/krishimitra/src/pages/` — Dashboard, Advisor, Disease, Market, Weather pages
- `artifacts/krishimitra/src/components/layout.tsx` — sidebar nav layout
- `artifacts/api-server/src/routes/` — gemini/, disease/, market/, weather/, dashboard/
- `lib/db/src/schema/` — conversations.ts, messages.ts, disease-detections.ts
- `lib/api-spec/` — OpenAPI spec (source of truth for API contracts)
- `lib/api-zod/src/generated/` — generated Zod validators
- `lib/api-client-react/src/generated/` — generated React Query hooks

## Architecture decisions

- Gemini chat uses SSE streaming (POST → text/event-stream); frontend reads chunks with ReadableStream
- `@google/*` removed from esbuild external list so `@google/genai` gets bundled into api-server dist
- Disease detection: client converts image to base64, sends to server, Gemini vision analyzes it, result stored in DB
- Weather/market use rich mock data (no external API keys needed)
- All DB models exported from `@workspace/db`; Zod schemas from `@workspace/api-zod`

## Product

5 pages:
1. **Dashboard** — Impact stats (yield, water savings, farmers covered), quick-access cards
2. **AI Advisor** — Real-time streaming chat with Gemini, conversation history, multilingual support
3. **Disease Scan** — Upload crop photo → Gemini vision identifies disease, severity, treatment
4. **Market Prices** — Live mandi prices for 12 major crops across India
5. **Weather** — 7-day forecast with farming advisory (location search supported)

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- `@google/genai` must NOT be in esbuild's external list in `build.mjs` — it's bundled from the integrations lib
- After any schema change, run `pnpm --filter @workspace/db run push` then restart the API server
- Gemini role mapping: `assistant` → `model` (Gemini API uses "model" not "assistant")
- SSE streaming: frontend must use `${BASE_URL.replace(/\/$/, "")}/api/...` — not root-relative paths

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
