import { motion } from 'framer-motion';

export function Scene4() {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center overflow-hidden bg-[#0A1A0A]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 2 }}
    >
      <motion.div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, #1A331A 0%, #0A1A0A 100%)',
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
      />
      
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
      >
        <h1 className="text-[8vw] font-bold text-[#FDFBF7] mb-[4vh] leading-none">
          KrishiMitra <span className="text-[#E6B325]">AI</span>
        </h1>
        <p className="text-[3vw] text-[#FDFBF7]/80 tracking-wide">
          Empowering every farmer with intelligence.
        </p>
      </motion.div>
    </motion.div>
  );
}
