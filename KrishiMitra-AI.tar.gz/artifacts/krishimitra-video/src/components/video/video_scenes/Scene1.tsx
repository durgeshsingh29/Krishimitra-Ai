import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Scene1() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 500),
      setTimeout(() => setPhase(2), 2000),
      setTimeout(() => setPhase(3), 4000),
      setTimeout(() => setPhase(4), 6000),
      setTimeout(() => setPhase(5), 8000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center overflow-hidden"
      initial={{ opacity: 0, scale: 1.1 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 1.5 }}
    >
      <div className="absolute inset-0 bg-[#1A331A] overflow-hidden">
        {/* Animated background elements */}
        <motion.div
          className="absolute w-[80vw] h-[80vw] rounded-full blur-[100px] opacity-20"
          style={{ background: 'radial-gradient(circle, #E6B325, transparent)' }}
          animate={{ x: ['-20%', '20%', '-20%'], y: ['-10%', '10%', '-10%'] }}
          transition={{ duration: 15, repeat: Infinity, ease: 'easeInOut' }}
        />
      </div>

      <div className="relative z-10 text-center px-[10vw]">
        <motion.h2
          className="text-[4vw] font-medium text-[#E6B325] tracking-wide uppercase mb-4"
          initial={{ opacity: 0, y: 30 }}
          animate={phase >= 1 ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        >
          150M+ Indian Farmers
        </motion.h2>

        <motion.h1
          className="text-[6vw] font-bold text-[#FDFBF7] leading-tight"
          initial={{ opacity: 0, y: 40 }}
          animate={phase >= 2 ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          Lack real-time crop intelligence
        </motion.h1>

        <motion.div
          className="mt-12 h-[2px] bg-[#E6B325] mx-auto"
          initial={{ width: 0 }}
          animate={phase >= 3 ? { width: '20vw' } : { width: 0 }}
          transition={{ duration: 1, ease: 'easeInOut' }}
        />

        <motion.p
          className="mt-12 text-[3vw] text-[#FDFBF7]/80 max-w-[60vw] mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={phase >= 4 ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 1 }}
        >
          Until now.
        </motion.p>
      </div>
    </motion.div>
  );
}
