import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Scene3() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 1000),
      setTimeout(() => setPhase(2), 4000),
      setTimeout(() => setPhase(3), 7000),
      setTimeout(() => setPhase(4), 10000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  const stats = [
    { value: '30%', label: 'Yield Increase' },
    { value: '40%', label: 'Water Savings' },
    { value: '22', label: 'Languages' },
  ];

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center overflow-hidden bg-[#1A331A]"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 1.5 }}
    >
      <div className="flex justify-around w-[90vw]">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            className="flex flex-col items-center"
            initial={{ opacity: 0, y: 50, scale: 0.8 }}
            animate={phase >= i + 1 ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 50, scale: 0.8 }}
            transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          >
            <motion.span className="text-[10vw] font-bold text-[#E6B325] leading-none mb-4">
              {stat.value}
            </motion.span>
            <motion.span className="text-[3vw] text-[#FDFBF7] uppercase tracking-wider font-medium">
              {stat.label}
            </motion.span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
