import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function Scene2() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 1000),
      setTimeout(() => setPhase(2), 5000),
      setTimeout(() => setPhase(3), 10000),
      setTimeout(() => setPhase(4), 15000),
      setTimeout(() => setPhase(5), 20000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  const features = [
    { title: 'AI Crop Advisor', desc: 'Chat in 22+ Indian languages' },
    { title: 'Disease Detection', desc: 'Upload photo → Instant treatment' },
    { title: 'Live Mandi Prices', desc: 'Real-time rates for 12 major crops' },
    { title: 'Smart Weather', desc: '7-day forecast with farming advisory' },
  ];

  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center overflow-hidden bg-[#0A1A0A]"
      initial={{ opacity: 0, y: '10%' }}
      animate={{ opacity: 1, y: '0%' }}
      exit={{ opacity: 0, y: '-10%' }}
      transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
    >
      <motion.h2
        className="absolute top-[15vh] text-[5vw] font-bold text-[#FDFBF7]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 1 }}
      >
        KrishiMitra <span className="text-[#E6B325]">AI</span>
      </motion.h2>

      <div className="grid grid-cols-2 gap-[4vw] mt-[10vh] w-[80vw]">
        {features.map((feat, i) => (
          <motion.div
            key={i}
            className="bg-[#1A331A] p-[3vw] border-l-4 border-[#E6B325] rounded-r-xl shadow-2xl"
            initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
            animate={phase >= i + 1 ? { opacity: 1, x: 0 } : { opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
            transition={{ type: 'spring', stiffness: 100, damping: 20 }}
          >
            <h3 className="text-[2.5vw] font-bold text-[#E6B325] mb-2">{feat.title}</h3>
            <p className="text-[1.8vw] text-[#FDFBF7]/90">{feat.desc}</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
