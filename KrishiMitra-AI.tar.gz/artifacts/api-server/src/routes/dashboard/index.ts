import { Router, type IRouter } from "express";
import { db, conversations, diseaseDetections } from "@workspace/db";
import { count } from "drizzle-orm";

const router: IRouter = Router();

// GET /dashboard/stats
router.get("/dashboard/stats", async (_req, res): Promise<void> => {
  const [convCount] = await db.select({ count: count() }).from(conversations);
  const [detectionCount] = await db.select({ count: count() }).from(diseaseDetections);

  res.json({
    totalAdvisories: Number(convCount?.count ?? 0),
    totalDetections: Number(detectionCount?.count ?? 0),
    cropYieldIncrease: 30,
    waterSavings: 40,
    diseasesDetected: Number(detectionCount?.count ?? 0),
    languagesSupported: 22,
    farmersCovered: "150M+",
  });
});

export default router;
