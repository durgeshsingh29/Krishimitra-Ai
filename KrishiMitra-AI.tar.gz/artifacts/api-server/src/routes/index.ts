import { Router, type IRouter } from "express";
import healthRouter from "./health";
import geminiRouter from "./gemini";
import diseaseRouter from "./disease";
import marketRouter from "./market";
import weatherRouter from "./weather";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(geminiRouter);
router.use(diseaseRouter);
router.use(marketRouter);
router.use(weatherRouter);
router.use(dashboardRouter);

export default router;
