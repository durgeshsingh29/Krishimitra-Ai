import { Router, type IRouter } from "express";

const router: IRouter = Router();

const weatherByLocation: Record<string, object> = {
  "delhi": {
    location: "New Delhi, Delhi",
    temperature: 38,
    humidity: 45,
    rainfall: 0,
    windSpeed: 12,
    condition: "Sunny & Hot",
    forecast: [
      { day: "Today", high: 38, low: 27, condition: "Sunny", rainfall: 0 },
      { day: "Tomorrow", high: 36, low: 26, condition: "Partly Cloudy", rainfall: 2 },
      { day: "Wed", high: 34, low: 25, condition: "Cloudy", rainfall: 8 },
      { day: "Thu", high: 32, low: 24, condition: "Light Rain", rainfall: 15 },
      { day: "Fri", high: 33, low: 25, condition: "Partly Cloudy", rainfall: 5 },
      { day: "Sat", high: 35, low: 26, condition: "Sunny", rainfall: 0 },
      { day: "Sun", high: 37, low: 27, condition: "Sunny & Hot", rainfall: 0 },
    ],
  },
  "mumbai": {
    location: "Mumbai, Maharashtra",
    temperature: 31,
    humidity: 82,
    rainfall: 12,
    windSpeed: 18,
    condition: "Humid & Cloudy",
    forecast: [
      { day: "Today", high: 31, low: 26, condition: "Heavy Rain", rainfall: 45 },
      { day: "Tomorrow", high: 29, low: 25, condition: "Thunderstorm", rainfall: 60 },
      { day: "Wed", high: 30, low: 25, condition: "Heavy Rain", rainfall: 50 },
      { day: "Thu", high: 31, low: 26, condition: "Moderate Rain", rainfall: 30 },
      { day: "Fri", high: 32, low: 26, condition: "Light Rain", rainfall: 15 },
      { day: "Sat", high: 33, low: 27, condition: "Partly Cloudy", rainfall: 5 },
      { day: "Sun", high: 32, low: 26, condition: "Cloudy", rainfall: 10 },
    ],
  },
  "punjab": {
    location: "Ludhiana, Punjab",
    temperature: 35,
    humidity: 52,
    rainfall: 0,
    windSpeed: 10,
    condition: "Clear & Warm",
    forecast: [
      { day: "Today", high: 35, low: 24, condition: "Sunny", rainfall: 0 },
      { day: "Tomorrow", high: 37, low: 25, condition: "Sunny & Hot", rainfall: 0 },
      { day: "Wed", high: 36, low: 25, condition: "Partly Cloudy", rainfall: 3 },
      { day: "Thu", high: 33, low: 23, condition: "Cloudy", rainfall: 10 },
      { day: "Fri", high: 31, low: 22, condition: "Light Rain", rainfall: 18 },
      { day: "Sat", high: 33, low: 23, condition: "Partly Cloudy", rainfall: 5 },
      { day: "Sun", high: 35, low: 24, condition: "Sunny", rainfall: 0 },
    ],
  },
};

const defaultWeather = {
  location: "Pune, Maharashtra",
  temperature: 28,
  humidity: 65,
  rainfall: 5,
  windSpeed: 14,
  condition: "Partly Cloudy",
  forecast: [
    { day: "Today", high: 28, low: 20, condition: "Partly Cloudy", rainfall: 5 },
    { day: "Tomorrow", high: 30, low: 21, condition: "Mostly Sunny", rainfall: 2 },
    { day: "Wed", high: 29, low: 21, condition: "Cloudy", rainfall: 12 },
    { day: "Thu", high: 27, low: 20, condition: "Light Rain", rainfall: 20 },
    { day: "Fri", high: 28, low: 20, condition: "Partly Cloudy", rainfall: 8 },
    { day: "Sat", high: 30, low: 21, condition: "Sunny", rainfall: 0 },
    { day: "Sun", high: 31, low: 22, condition: "Sunny", rainfall: 0 },
  ],
};

// GET /weather
router.get("/weather", async (req, res): Promise<void> => {
  const location = (req.query.location as string | undefined)?.toLowerCase() ?? "";
  const key = Object.keys(weatherByLocation).find((k) => location.includes(k));
  res.json(key ? weatherByLocation[key] : defaultWeather);
});

export default router;
