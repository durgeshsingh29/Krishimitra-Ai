import { Router, type IRouter } from "express";

const router: IRouter = Router();

// GET /market/prices
router.get("/market/prices", async (_req, res): Promise<void> => {
  const prices = [
    { crop: "Wheat", price: 2275, unit: "quintal", market: "Delhi APMC", change: 1.2, trend: "up" },
    { crop: "Rice (Paddy)", price: 2183, unit: "quintal", market: "Punjab Mandi", change: 0.8, trend: "up" },
    { crop: "Maize", price: 1850, unit: "quintal", market: "Maharashtra APMC", change: -0.5, trend: "down" },
    { crop: "Soybean", price: 4450, unit: "quintal", market: "MP Mandi", change: 2.3, trend: "up" },
    { crop: "Cotton", price: 6780, unit: "quintal", market: "Gujarat APMC", change: -1.1, trend: "down" },
    { crop: "Sugarcane", price: 315, unit: "quintal", market: "UP Cooperative", change: 0.0, trend: "stable" },
    { crop: "Tomato", price: 1200, unit: "quintal", market: "Nashik APMC", change: 5.6, trend: "up" },
    { crop: "Onion", price: 1800, unit: "quintal", market: "Lasalgaon", change: -2.4, trend: "down" },
    { crop: "Potato", price: 900, unit: "quintal", market: "Agra Mandi", change: 1.5, trend: "up" },
    { crop: "Mustard", price: 5350, unit: "quintal", market: "Rajasthan Mandi", change: 0.7, trend: "up" },
    { crop: "Groundnut", price: 5600, unit: "quintal", market: "Gujarat APMC", change: -0.3, trend: "down" },
    { crop: "Chickpea", price: 5200, unit: "quintal", market: "MP Mandi", change: 1.8, trend: "up" },
  ];
  res.json(prices);
});

export default router;
