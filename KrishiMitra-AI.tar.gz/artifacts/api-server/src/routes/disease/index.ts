import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, diseaseDetections } from "@workspace/db";
import { ai } from "@workspace/integrations-gemini-ai";
import { DetectDiseaseBody } from "@workspace/api-zod";
import { logger } from "../../lib/logger";

const router: IRouter = Router();

// POST /disease/detect
router.post("/disease/detect", async (req, res): Promise<void> => {
  const parsed = DetectDiseaseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { imageBase64, cropName, language = "en" } = parsed.data;

  try {
    const prompt = `You are an expert agricultural plant pathologist specializing in Indian crops.

Analyze this image of a ${cropName} plant and provide a detailed disease assessment.

${language !== "en" ? `Please respond in ${language} language for the analysis text.` : ""}

Respond ONLY with a valid JSON object in this exact format (no markdown, no code blocks):
{
  "diseaseName": "exact disease name or 'Healthy Plant' if no disease",
  "severity": "Low|Medium|High|Critical or 'None' if healthy",
  "confidence": 0.85,
  "description": "detailed description of what you see",
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"],
  "preventionTips": ["prevention tip 1", "prevention tip 2", "prevention tip 3"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: imageBase64,
              },
            },
          ],
        },
      ],
      config: { maxOutputTokens: 8192 },
    });

    const rawText = response.text ?? "";
    // Strip markdown code blocks if present
    const jsonText = rawText.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

    let result;
    try {
      result = JSON.parse(jsonText);
    } catch {
      // Fallback if JSON parsing fails
      result = {
        diseaseName: "Analysis Error",
        severity: "Unknown",
        confidence: 0,
        description: "Unable to parse AI response. Please try again with a clearer image.",
        recommendations: ["Consult a local agricultural expert", "Try uploading a clearer image"],
        preventionTips: ["Maintain good crop hygiene", "Regular field monitoring"],
      };
    }

    // Save to DB
    await db.insert(diseaseDetections).values({
      cropName,
      diseaseName: result.diseaseName,
      severity: result.severity,
      confidence: result.confidence,
      description: result.description,
      recommendations: result.recommendations,
      preventionTips: result.preventionTips,
    });

    res.json(result);
  } catch (err) {
    logger.error({ err }, "Error detecting disease");
    res.status(500).json({ error: "Disease detection failed" });
  }
});

// GET /disease/detections
router.get("/disease/detections", async (_req, res): Promise<void> => {
  const detections = await db
    .select({
      id: diseaseDetections.id,
      cropName: diseaseDetections.cropName,
      diseaseName: diseaseDetections.diseaseName,
      severity: diseaseDetections.severity,
      confidence: diseaseDetections.confidence,
      createdAt: diseaseDetections.createdAt,
    })
    .from(diseaseDetections)
    .orderBy(desc(diseaseDetections.createdAt))
    .limit(20);
  res.json(detections);
});

export default router;
