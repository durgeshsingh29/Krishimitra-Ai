import { Link, useLocation } from "wouter";
import { 
  Sprout, 
  LayoutDashboard, 
  MessageSquareText, 
  ScanSearch, 
  LineChart, 
  CloudSun,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/advisor", label: "AI Advisor", icon: MessageSquareText },
  { href: "/disease", label: "Disease Scan", icon: ScanSearch },
  { href: "/market", label: "Market Prices", icon: LineChart },
  { href: "/weather", label: "Weather", icon: CloudSun },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const NavLinks = ({ onClick }: { onClick?: () => void }) => (
    <div className="flex flex-col gap-2">
      {NAV_ITEMS.map((item) => {
        const isActive = location === item.href;
        return (
          <Link 
            key={item.href} 
            href={item.href}
            onClick={onClick}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all font-medium ${
              isActive 
                ? "bg-sidebar-primary text-sidebar-primary-foreground" 
                : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            }`}
          >
            <item.icon className={`h-5 w-5 ${isActive ? "opacity-100" : "opacity-70"}`} />
            {item.label}
          </Link>
        );
      })}
    </div>
  );

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background w-full">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-sidebar text-sidebar-foreground border-b border-sidebar-border sticky top-0 z-50">
        <div className="flex items-center gap-2 font-bold text-lg">
          <Sprout className="h-6 w-6 text-sidebar-primary" />
          <span>KrishiMitra</span>
        </div>
        <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-sidebar-foreground hover:bg-sidebar-accent">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="bg-sidebar border-sidebar-border p-6 w-72">
            <div className="flex items-center gap-2 font-bold text-xl text-sidebar-foreground mb-8">
              <Sprout className="h-7 w-7 text-sidebar-primary" />
              <span>KrishiMitra</span>
            </div>
            <NavLinks onClick={() => setMobileMenuOpen(false)} />
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-72 flex-col bg-sidebar border-r border-sidebar-border h-[100dvh] sticky top-0">
        <div className="p-6">
          <div className="flex items-center gap-3 font-bold text-2xl text-sidebar-foreground mb-1">
            <Sprout className="h-8 w-8 text-sidebar-primary" />
            <span className="tracking-tight font-heading">KrishiMitra</span>
          </div>
          <p className="text-sidebar-foreground/60 text-sm ml-11">Farm Intelligence</p>
        </div>
        
        <div className="flex-1 px-4 py-4 overflow-y-auto">
          <NavLinks />
        </div>
        
        <div className="p-6 mt-auto border-t border-sidebar-border/50">
          <div className="bg-sidebar-accent rounded-lg p-4 text-sidebar-accent-foreground text-sm">
            <p className="font-semibold mb-1">Need help?</p>
            <p className="opacity-80">Call our toll-free farmer helpline at 1800-120-4040</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-x-hidden min-h-[calc(100dvh-73px)] md:min-h-[100dvh] flex flex-col">
        {children}
      </main>
    </div>
  );
}
