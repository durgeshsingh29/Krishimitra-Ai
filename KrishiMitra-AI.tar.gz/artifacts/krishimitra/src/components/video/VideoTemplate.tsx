import { motion, AnimatePresence } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video/hooks';
import { Scene1 } from './video_scenes/Scene1';
import { Scene2 } from './video_scenes/Scene2';
import { Scene3 } from './video_scenes/Scene3';
import { Scene4 } from './video_scenes/Scene4';

const SCENE_DURATIONS = { open: 4000, features: 8000, stats: 5000, close: 4000 };

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({ durations: SCENE_DURATIONS });

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#1A2E1A] text-white">
      {/* Background layer */}
      <div className="absolute inset-0 z-0">
        <motion.div className="absolute inset-0 bg-[#0A1A0A] opacity-80" />
      </div>

      <AnimatePresence mode="popLayout">
        {currentScene === 0 && <Scene1 key="open" />}
        {currentScene === 1 && <Scene2 key="features" />}
        {currentScene === 2 && <Scene3 key="stats" />}
        {currentScene === 3 && <Scene4 key="close" />}
      </AnimatePresence>
    </div>
  );
}
