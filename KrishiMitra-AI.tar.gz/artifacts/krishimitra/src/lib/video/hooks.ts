import { useState, useEffect } from 'react';

export function useVideoPlayer({ durations }: { durations: Record<string, number> }) {
  const [currentScene, setCurrentScene] = useState(0);

  useEffect(() => {
    // Basic mock implementation of useVideoPlayer
    // Loop through scenes
    const sceneDurations = Object.values(durations);
    
    if (sceneDurations.length === 0) return;

    let timeoutId: NodeJS.Timeout;
    
    const playScene = (index: number) => {
      setCurrentScene(index);
      timeoutId = setTimeout(() => {
        playScene((index + 1) % sceneDurations.length);
      }, sceneDurations[index]);
    };

    if (window.startRecording) window.startRecording();
    
    playScene(0);

    return () => {
      clearTimeout(timeoutId);
      if (window.stopRecording) window.stopRecording();
    };
  }, []);

  return { currentScene };
}
