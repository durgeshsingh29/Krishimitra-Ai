import { useState, useRef, useEffect } from "react";
import { useListGeminiConversations, useCreateGeminiConversation, useDeleteGeminiConversation, getListGeminiConversationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Trash2, Send, Sprout, Loader2, MessageSquare } from "lucide-react";

type Message = { role: "user" | "assistant"; content: string; streaming?: boolean };

export default function Advisor() {
  const queryClient = useQueryClient();
  const { data: conversations, isLoading } = useListGeminiConversations();
  const createConv = useCreateGeminiConversation();
  const deleteConv = useDeleteGeminiConversation();

  const [activeId, setActiveId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleNewConversation = () => {
    const title = newTitle.trim() || "New Conversation";
    createConv.mutate(
      { data: { title } },
      {
        onSuccess: (conv) => {
          queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
          setActiveId(conv.id);
          setMessages([]);
          setNewTitle("");
        },
      }
    );
  };

  const handleDelete = (id: number) => {
    deleteConv.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
          if (activeId === id) {
            setActiveId(null);
            setMessages([]);
          }
        },
      }
    );
  };

  const handleSend = async () => {
    if (!input.trim() || !activeId || streaming) return;
    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setStreaming(true);

    const assistantIdx = messages.length + 1;
    setMessages((prev) => [...prev, { role: "assistant", content: "", streaming: true }]);

    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      const resp = await fetch(`${base}/api/gemini/conversations/${activeId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: userMsg }),
      });

      const reader = resp.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let full = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop()!;
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const json = JSON.parse(line.slice(6));
              if (json.done) break;
              if (json.content) {
                full += json.content;
                setMessages((prev) => {
                  const updated = [...prev];
                  updated[updated.length - 1] = { role: "assistant", content: full, streaming: true };
                  return updated;
                });
              }
            } catch {
              // skip malformed
            }
          }
        }
      }

      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1] = { role: "assistant", content: full, streaming: false };
        return updated;
      });
    } catch {
      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1] = {
          role: "assistant",
          content: "Sorry, something went wrong. Please try again.",
          streaming: false,
        };
        return updated;
      });
    } finally {
      setStreaming(false);
    }
  };

  return (
    <div className="flex h-[calc(100dvh-0px)] md:h-[100dvh] overflow-hidden">
      {/* Sidebar */}
      <div className="w-72 hidden md:flex flex-col border-r border-border bg-muted/30">
        <div className="p-4 border-b border-border">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">New Conversation</p>
          <div className="flex gap-2">
            <Input
              placeholder="Topic (optional)"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleNewConversation()}
              className="text-sm"
              data-testid="input-new-conversation"
            />
            <Button
              size="icon"
              onClick={handleNewConversation}
              disabled={createConv.isPending}
              data-testid="button-create-conversation"
              className="shrink-0"
            >
              {createConv.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {isLoading
              ? Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-10 w-full rounded-lg" />)
              : conversations?.length === 0
              ? (
                <p className="text-xs text-muted-foreground text-center py-8 px-4">
                  No conversations yet. Start one above.
                </p>
              )
              : conversations?.map((conv) => (
                <div
                  key={conv.id}
                  className={`group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-all ${
                    activeId === conv.id ? "bg-primary text-primary-foreground" : "hover:bg-accent"
                  }`}
                  onClick={() => {
                    setActiveId(conv.id);
                    setMessages([]);
                  }}
                  data-testid={`conversation-item-${conv.id}`}
                >
                  <MessageSquare className="h-4 w-4 shrink-0 opacity-70" />
                  <span className="text-sm flex-1 truncate font-medium">{conv.title}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-6 w-6 opacity-0 group-hover:opacity-100 shrink-0 ${
                      activeId === conv.id ? "hover:bg-primary-foreground/20 text-primary-foreground" : ""
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(conv.id);
                    }}
                    data-testid={`button-delete-conversation-${conv.id}`}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-border">
          <p className="text-xs text-muted-foreground">Supported: Hindi, English, Marathi, Tamil, Telugu, Kannada, Punjabi + 15 more</p>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {activeId === null ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-6 p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <Sprout className="h-10 w-10 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">KrishiMitra AI Advisor</h2>
              <p className="text-muted-foreground max-w-sm">
                Ask about crops, diseases, irrigation, market prices, weather, or any farming question — in your language.
              </p>
            </div>
            <div className="flex flex-col gap-2 w-full max-w-sm md:hidden">
              <Input
                placeholder="Conversation topic (optional)"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
              />
              <Button onClick={handleNewConversation} disabled={createConv.isPending} className="w-full">
                {createConv.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Start New Conversation
              </Button>
            </div>
            <div className="hidden md:block">
              <Button onClick={handleNewConversation} disabled={createConv.isPending}>
                {createConv.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Start New Conversation
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mt-2">
              {[
                "How do I manage wheat rust disease?",
                "Best time to sow paddy in Punjab?",
                "मेरी फसल पर सफेद धब्बे क्यों हैं?",
                "Cotton bollworm treatment options",
              ].map((q) => (
                <button
                  key={q}
                  className="text-left p-3 text-sm rounded-lg border border-border hover:bg-accent transition-colors"
                  onClick={() => {
                    handleNewConversation();
                    setTimeout(() => setInput(q), 300);
                  }}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            <div className="px-4 py-3 border-b border-border bg-card flex items-center gap-3">
              <MessageSquare className="h-5 w-5 text-primary" />
              <span className="font-semibold text-sm">
                {conversations?.find((c) => c.id === activeId)?.title ?? "Conversation"}
              </span>
            </div>

            <ScrollArea className="flex-1 p-4" ref={scrollRef as React.RefObject<HTMLDivElement>}>
              <div className="space-y-4 max-w-3xl mx-auto">
                {messages.length === 0 && (
                  <div className="text-center text-muted-foreground text-sm py-8">
                    Ask your farming question below...
                  </div>
                )}
                {messages.map((msg, i) => (
                  <div
                    key={i}
                    className={`flex gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200 ${
                      msg.role === "user" ? "justify-end" : "justify-start"
                    }`}
                    data-testid={`message-${msg.role}-${i}`}
                  >
                    {msg.role === "assistant" && (
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-1">
                        <Sprout className="h-4 w-4 text-primary" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground rounded-tr-sm"
                          : "bg-card border border-border rounded-tl-sm"
                      }`}
                    >
                      {msg.content}
                      {msg.streaming && (
                        <span className="inline-block w-1.5 h-4 bg-primary/60 animate-pulse ml-1 rounded-sm" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="p-4 border-t border-border bg-background">
              <div className="flex gap-2 max-w-3xl mx-auto">
                <Input
                  placeholder="Ask in any language — Hindi, English, Marathi..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
                  disabled={streaming}
                  className="text-sm"
                  data-testid="input-message"
                />
                <Button
                  onClick={handleSend}
                  disabled={!input.trim() || streaming}
                  size="icon"
                  data-testid="button-send"
                >
                  {streaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
