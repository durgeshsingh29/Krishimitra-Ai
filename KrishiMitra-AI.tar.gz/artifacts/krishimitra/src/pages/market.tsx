import { useGetMarketPrices } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, LineChart, RefreshCw } from "lucide-react";

export default function Market() {
  const { data: prices, isLoading, isError, refetch, isFetching } = useGetMarketPrices();

  const trendIcon = (trend: string) => {
    if (trend === "up") return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (trend === "down") return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const trendClass = (trend: string) => {
    if (trend === "up") return "text-green-600";
    if (trend === "down") return "text-red-500";
    return "text-muted-foreground";
  };

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Market Prices</h1>
          <p className="text-muted-foreground mt-1">Live mandi prices for major crops across India. Updated daily.</p>
        </div>
        <button
          onClick={() => refetch()}
          className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground"
          data-testid="button-refresh-prices"
          title="Refresh prices"
        >
          <RefreshCw className={`h-5 w-5 ${isFetching ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Summary strip */}
      {!isLoading && prices && (
        <div className="grid grid-cols-3 gap-4">
          <Card className="bg-green-500/5 border-green-500/20">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Rising Today</p>
              <p className="text-2xl font-bold text-green-600">
                {prices.filter((p) => p.trend === "up").length}
              </p>
              <p className="text-xs text-muted-foreground">crops</p>
            </CardContent>
          </Card>
          <Card className="bg-red-500/5 border-red-500/20">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Falling Today</p>
              <p className="text-2xl font-bold text-red-500">
                {prices.filter((p) => p.trend === "down").length}
              </p>
              <p className="text-xs text-muted-foreground">crops</p>
            </CardContent>
          </Card>
          <Card className="bg-muted/30">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Markets Tracked</p>
              <p className="text-2xl font-bold">
                {new Set(prices.map((p) => p.market)).size}
              </p>
              <p className="text-xs text-muted-foreground">mandis</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Price Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <LineChart className="h-5 w-5 text-primary" />
            Crop Prices (per quintal)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {Array(8).fill(0).map((_, i) => <Skeleton key={i} className="h-12 w-full rounded-lg" />)}
            </div>
          ) : isError ? (
            <div className="p-6 text-center text-muted-foreground">Failed to load prices.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="text-left px-6 py-3 font-semibold text-muted-foreground">Crop</th>
                    <th className="text-right px-4 py-3 font-semibold text-muted-foreground">Price (Rs.)</th>
                    <th className="text-right px-4 py-3 font-semibold text-muted-foreground hidden sm:table-cell">Market</th>
                    <th className="text-right px-6 py-3 font-semibold text-muted-foreground">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {prices?.map((p, i) => (
                    <tr
                      key={p.crop}
                      className={`border-b border-border/50 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}
                      data-testid={`market-row-${p.crop.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <td className="px-6 py-4">
                        <div className="font-semibold">{p.crop}</div>
                        <div className="text-xs text-muted-foreground">per {p.unit}</div>
                      </td>
                      <td className="px-4 py-4 text-right font-mono font-bold text-lg">
                        ₹{p.price.toLocaleString("en-IN")}
                      </td>
                      <td className="px-4 py-4 text-right text-muted-foreground hidden sm:table-cell text-xs">
                        {p.market}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className={`flex items-center justify-end gap-1.5 font-semibold ${trendClass(p.trend)}`}>
                          {trendIcon(p.trend)}
                          <span>{p.change === 0 ? "No change" : `${p.change > 0 ? "+" : ""}${p.change}%`}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center">
        Data sourced from APMC mandis across India. Prices are indicative and may vary by grade and quality.
      </p>
    </div>
  );
}
