import { useGetDashboardStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Droplets, Sprout, Languages, Users, LineChart, AlertTriangle, ScanSearch } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: stats, isLoading, isError } = useGetDashboardStats();

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">Welcome back, Kisan.</h1>
        <p className="text-muted-foreground mt-2 text-lg">Here is your farm's intelligence snapshot for today.</p>
      </div>

      {/* Impact Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? (
          Array(4).fill(0).map((_, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-8 w-8 rounded-full" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-1" />
                <Skeleton className="h-3 w-32" />
              </CardContent>
            </Card>
          ))
        ) : isError || !stats ? (
          <div className="col-span-full p-6 text-center text-muted-foreground border rounded-lg bg-muted/30">
            Failed to load dashboard statistics.
          </div>
        ) : (
          <>
            <StatCard 
              title="Yield Increase" 
              value={`${stats.cropYieldIncrease}%`} 
              desc="Average improvement" 
              icon={Sprout} 
              color="text-primary" 
              bg="bg-primary/10" 
            />
            <StatCard 
              title="Water Saved" 
              value={`${stats.waterSavings}%`} 
              desc="Compared to last season" 
              icon={Droplets} 
              color="text-blue-500" 
              bg="bg-blue-500/10" 
            />
            <StatCard 
              title="Diseases Detected" 
              value={stats.totalDetections.toString()} 
              desc="Early interventions" 
              icon={AlertTriangle} 
              color="text-amber-500" 
              bg="bg-amber-500/10" 
            />
            <StatCard 
              title="Farmers Covered" 
              value={stats.farmersCovered} 
              desc="Across 4 states" 
              icon={Users} 
              color="text-purple-500" 
              bg="bg-purple-500/10" 
            />
          </>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link href="/advisor">
          <Card className="hover-elevate cursor-pointer transition-all border-primary/20 bg-gradient-to-br from-card to-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-3 bg-primary/20 text-primary rounded-xl">
                  <Languages className="h-6 w-6" />
                </div>
                Ask AI Advisor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Get instant answers to your farming questions in your local language. Voice or text.
              </p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/disease">
          <Card className="hover-elevate cursor-pointer transition-all border-amber-500/20 bg-gradient-to-br from-card to-amber-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-3 bg-amber-500/20 text-amber-600 rounded-xl">
                  <ScanSearch className="h-6 w-6" />
                </div>
                Scan Crop Disease
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Upload a photo of your crop to instantly identify diseases and get treatment recommendations.
              </p>
            </CardContent>
          </Card>
        </Link>
      </div>
      
    </div>
  );
}

function StatCard({ 
  title, 
  value, 
  desc, 
  icon: Icon,
  color,
  bg
}: { 
  title: string; 
  value: string; 
  desc: string; 
  icon: React.ElementType;
  color: string;
  bg: string;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className={`p-2 rounded-full ${bg} ${color}`}>
          <Icon className="h-4 w-4" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold font-heading tracking-tight">{value}</div>
        <p className="text-xs text-muted-foreground mt-1">{desc}</p>
      </CardContent>
    </Card>
  );
}
