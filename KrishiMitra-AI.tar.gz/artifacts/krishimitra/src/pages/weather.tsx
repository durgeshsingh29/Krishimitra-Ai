import { useState } from "react";
import { useGetWeather, getGetWeatherQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CloudSun, Droplets, Wind, Thermometer, Search, CloudRain, Sun, Cloud, Zap, CloudSnow } from "lucide-react";

const weatherIcon = (condition: string) => {
  const c = condition.toLowerCase();
  if (c.includes("thunder") || c.includes("storm")) return <Zap className="h-6 w-6 text-yellow-500" />;
  if (c.includes("snow")) return <CloudSnow className="h-6 w-6 text-blue-300" />;
  if (c.includes("rain") || c.includes("drizzle")) return <CloudRain className="h-6 w-6 text-blue-500" />;
  if (c.includes("cloudy") || c.includes("overcast")) return <Cloud className="h-6 w-6 text-gray-400" />;
  if (c.includes("sunny") || c.includes("hot")) return <Sun className="h-6 w-6 text-amber-500" />;
  return <CloudSun className="h-6 w-6 text-amber-400" />;
};

const largeWeatherIcon = (condition: string) => {
  const c = condition.toLowerCase();
  if (c.includes("thunder") || c.includes("storm")) return <Zap className="h-16 w-16 text-yellow-500" />;
  if (c.includes("snow")) return <CloudSnow className="h-16 w-16 text-blue-300" />;
  if (c.includes("rain") || c.includes("drizzle")) return <CloudRain className="h-16 w-16 text-blue-500" />;
  if (c.includes("cloudy") || c.includes("overcast")) return <Cloud className="h-16 w-16 text-gray-400" />;
  if (c.includes("sunny") || c.includes("hot")) return <Sun className="h-16 w-16 text-amber-500" />;
  return <CloudSun className="h-16 w-16 text-amber-400" />;
};

export default function Weather() {
  const [locationInput, setLocationInput] = useState("");
  const [searchedLocation, setSearchedLocation] = useState<string | undefined>(undefined);

  const { data: weather, isLoading, isError } = useGetWeather(
    searchedLocation ? { location: searchedLocation } : {},
    { query: { queryKey: getGetWeatherQueryKey({ location: searchedLocation }) } }
  );

  const handleSearch = () => {
    if (locationInput.trim()) {
      setSearchedLocation(locationInput.trim());
    }
  };

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Weather Forecast</h1>
        <p className="text-muted-foreground mt-1">Real-time weather and 7-day agricultural forecast for your region.</p>
      </div>

      {/* Location search */}
      <div className="flex gap-2 max-w-md">
        <Input
          placeholder="Enter location (e.g. Punjab, Delhi, Mumbai)"
          value={locationInput}
          onChange={(e) => setLocationInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          data-testid="input-location"
        />
        <Button onClick={handleSearch} data-testid="button-search-weather">
          <Search className="h-4 w-4" />
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-48 w-full rounded-2xl" />
          <div className="grid grid-cols-7 gap-2">
            {Array(7).fill(0).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
          </div>
        </div>
      ) : isError || !weather ? (
        <div className="text-center text-muted-foreground py-16 border border-dashed rounded-2xl">
          Failed to load weather data. Please try again.
        </div>
      ) : (
        <>
          {/* Current conditions */}
          <Card className="bg-gradient-to-br from-primary/10 via-card to-blue-500/5 border-primary/20 overflow-hidden">
            <CardContent className="p-6 md:p-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                <div className="flex items-center gap-6">
                  {largeWeatherIcon(weather.condition)}
                  <div>
                    <p className="text-5xl font-bold tracking-tight">{weather.temperature}°C</p>
                    <p className="text-xl text-muted-foreground mt-1">{weather.condition}</p>
                    <p className="text-sm text-muted-foreground mt-1 font-medium">{weather.location}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-1 gap-3 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Droplets className="h-4 w-4 text-blue-500" />
                    <span>Humidity: <span className="font-semibold text-foreground">{weather.humidity}%</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <CloudRain className="h-4 w-4 text-blue-400" />
                    <span>Rainfall: <span className="font-semibold text-foreground">{weather.rainfall}mm</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Wind className="h-4 w-4 text-gray-500" />
                    <span>Wind: <span className="font-semibold text-foreground">{weather.windSpeed} km/h</span></span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 7-day forecast */}
          <div>
            <h2 className="text-lg font-bold mb-4">7-Day Forecast</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              {weather.forecast?.map((day, i) => (
                <Card
                  key={i}
                  className={`text-center transition-all hover-elevate ${i === 0 ? "border-primary/30 bg-primary/5" : ""}`}
                  data-testid={`weather-day-${i}`}
                >
                  <CardContent className="p-3 space-y-2">
                    <p className={`text-xs font-semibold ${i === 0 ? "text-primary" : "text-muted-foreground"}`}>
                      {day.day}
                    </p>
                    <div className="flex justify-center">
                      {weatherIcon(day.condition)}
                    </div>
                    <div>
                      <p className="font-bold text-sm">{day.high}°</p>
                      <p className="text-xs text-muted-foreground">{day.low}°</p>
                    </div>
                    {day.rainfall > 0 && (
                      <div className="flex items-center justify-center gap-0.5 text-blue-500 text-xs">
                        <Droplets className="h-3 w-3" />
                        <span>{day.rainfall}mm</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Farming advisory */}
          <Card className="border-amber-500/20 bg-amber-500/5">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base text-amber-700">
                <Thermometer className="h-5 w-5" />
                Farming Advisory
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                {weather.humidity > 75 && (
                  <li className="flex gap-2">
                    <span className="text-amber-500 font-bold shrink-0">!</span>
                    High humidity detected. Watch for fungal diseases on crops. Apply preventive fungicide if needed.
                  </li>
                )}
                {weather.rainfall > 20 && (
                  <li className="flex gap-2">
                    <span className="text-blue-500 font-bold shrink-0">!</span>
                    Heavy rainfall expected. Ensure proper field drainage to prevent waterlogging.
                  </li>
                )}
                {weather.temperature > 36 && (
                  <li className="flex gap-2">
                    <span className="text-red-500 font-bold shrink-0">!</span>
                    Extreme heat alert. Irrigate early morning or evening. Avoid pesticide spraying during peak heat.
                  </li>
                )}
                {weather.windSpeed > 20 && (
                  <li className="flex gap-2">
                    <span className="text-gray-500 font-bold shrink-0">!</span>
                    Strong winds. Avoid aerial spraying. Secure tall crops like sugarcane and maize.
                  </li>
                )}
                <li className="flex gap-2">
                  <span className="text-green-600 font-bold shrink-0">✓</span>
                  Current conditions are generally suitable for fieldwork. Monitor soil moisture before irrigation.
                </li>
              </ul>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
