import { useState, useRef } from "react";
import { useDetectDisease, useListDiseaseDetections, getListDiseaseDetectionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Upload, ScanSearch, AlertTriangle, CheckCircle2, Clock, Leaf, ShieldCheck, Loader2, ImageIcon } from "lucide-react";

type DetectionResult = {
  diseaseName: string;
  severity: string;
  confidence: number;
  description: string;
  recommendations: string[];
  preventionTips: string[];
};

export default function Disease() {
  const queryClient = useQueryClient();
  const detectDisease = useDetectDisease();
  const { data: detections, isLoading: loadingHistory } = useListDiseaseDetections();

  const [cropName, setCropName] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setImagePreview(dataUrl);
      setImageBase64(dataUrl.split(",")[1]);
      setResult(null);
    };
  };

  const handleDetect = () => {
    if (!imageBase64 || !cropName.trim()) return;
    detectDisease.mutate(
      { data: { imageBase64, cropName: cropName.trim(), language: "en" } },
      {
        onSuccess: (data) => {
          setResult(data as DetectionResult);
          queryClient.invalidateQueries({ queryKey: getListDiseaseDetectionsQueryKey() });
        },
      }
    );
  };

  const severityColor = (s: string) => {
    switch (s.toLowerCase()) {
      case "none": return "bg-green-500/10 text-green-700 border-green-500/30";
      case "low": return "bg-yellow-500/10 text-yellow-700 border-yellow-500/30";
      case "medium": return "bg-orange-500/10 text-orange-700 border-orange-500/30";
      case "high": return "bg-red-500/10 text-red-700 border-red-500/30";
      case "critical": return "bg-red-700/10 text-red-800 border-red-700/30";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Crop Disease Detection</h1>
        <p className="text-muted-foreground mt-1">Upload a photo of your crop to identify diseases using AI vision analysis.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Panel */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ScanSearch className="h-5 w-5 text-primary" />
              Scan Your Crop
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Image Upload */}
            <div
              className={`relative border-2 border-dashed rounded-xl overflow-hidden transition-all cursor-pointer ${
                imagePreview ? "border-primary/40 bg-primary/5" : "border-border hover:border-primary/40 hover:bg-primary/5"
              }`}
              style={{ minHeight: 200 }}
              onClick={() => fileInputRef.current?.click()}
              data-testid="image-upload-zone"
            >
              {imagePreview ? (
                <img src={imagePreview} alt="Crop preview" className="w-full h-52 object-cover" />
              ) : (
                <div className="flex flex-col items-center justify-center gap-3 py-12 text-muted-foreground">
                  <ImageIcon className="h-12 w-12 opacity-40" />
                  <div className="text-center">
                    <p className="font-medium text-sm">Click or drag to upload</p>
                    <p className="text-xs">JPG, PNG, WebP supported</p>
                  </div>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
                data-testid="input-image-file"
              />
            </div>

            {imagePreview && (
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                Change Image
              </Button>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium">Crop Name</label>
              <Input
                placeholder="e.g. Wheat, Rice, Tomato, Cotton..."
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                data-testid="input-crop-name"
              />
            </div>

            <Button
              className="w-full"
              onClick={handleDetect}
              disabled={!imageBase64 || !cropName.trim() || detectDisease.isPending}
              data-testid="button-detect-disease"
            >
              {detectDisease.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <ScanSearch className="h-4 w-4 mr-2" />
                  Analyze Crop
                </>
              )}
            </Button>

            {detectDisease.isError && (
              <p className="text-sm text-destructive text-center">Analysis failed. Please try again.</p>
            )}
          </CardContent>
        </Card>

        {/* Result Panel */}
        <div className="space-y-4">
          {detectDisease.isPending ? (
            <Card>
              <CardContent className="pt-6 space-y-3">
                <Skeleton className="h-6 w-48" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ) : result ? (
            <Card className="border-primary/20 animate-in fade-in duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <CardTitle className="text-xl">{result.diseaseName}</CardTitle>
                  <Badge className={`shrink-0 border ${severityColor(result.severity)}`}>
                    {result.severity} Severity
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    {Math.round(result.confidence * 100)}% confidence
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">{result.description}</p>

                <div>
                  <div className="flex items-center gap-2 mb-2 font-semibold text-sm">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    Treatment Recommendations
                  </div>
                  <ul className="space-y-1.5">
                    {result.recommendations.map((r, i) => (
                      <li key={i} className="text-sm flex gap-2">
                        <span className="text-primary font-bold shrink-0">{i + 1}.</span>
                        <span className="text-muted-foreground">{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2 font-semibold text-sm">
                    <ShieldCheck className="h-4 w-4 text-green-600" />
                    Prevention Tips
                  </div>
                  <ul className="space-y-1.5">
                    {result.preventionTips.map((t, i) => (
                      <li key={i} className="text-sm flex gap-2">
                        <Leaf className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                        <span className="text-muted-foreground">{t}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-muted/30 border-dashed">
              <CardContent className="flex flex-col items-center justify-center gap-3 py-16 text-center text-muted-foreground">
                <ScanSearch className="h-12 w-12 opacity-30" />
                <p className="text-sm">Upload an image and enter the crop name to see AI analysis results.</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Detection History */}
      <div>
        <h2 className="text-xl font-bold mb-4">Detection History</h2>
        {loadingHistory ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
          </div>
        ) : detections?.length === 0 ? (
          <div className="text-center text-muted-foreground py-10 border border-dashed rounded-xl">
            No detections yet. Run your first scan above.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {detections?.map((d) => (
              <Card key={d.id} className="hover-elevate transition-all" data-testid={`detection-record-${d.id}`}>
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold text-sm">{d.diseaseName}</p>
                      <p className="text-xs text-muted-foreground">{d.cropName}</p>
                    </div>
                    <Badge className={`text-xs border shrink-0 ${severityColor(d.severity)}`}>{d.severity}</Badge>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      {Math.round(d.confidence * 100)}%
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(d.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
